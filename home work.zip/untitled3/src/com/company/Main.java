package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
    String  str ="Привет, java-программист!";

    int indexM =str.indexOf("m"); //Нахождения символа в строке
    int getIndexM =str.indexOf("java"); //Нахождения слова в строке
        if (indexM == - 1) {
            System.out.println("Символ найден в индексе");
        } else {
            System.out.println("Символ найден в индексе"+indexM);
            if (indexM ==1){
                System.out.println("Слово yt слово не найдено");
            } else {
                System.out.println("Слово найдено в индексе");

            }
        }
}
    }

